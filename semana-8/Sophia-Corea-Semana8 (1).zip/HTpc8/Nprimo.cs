﻿using System;

namespace HTpc8
{
    class Nprimo

    {
        static void Main(string [] args)
        {
            //VARIABLES
            int n = 0; // Variable del número a ingresar
            int ContarValor = 0; // Contará los valores de vDivisor

            //ENTRADA
            // Solicitar al usuario un número a ingresar
            Console.WriteLine("Ingrese un número entero que no exceda 999,999: ");
            n = Int32.Parse(Console.ReadLine());
            
            // PROCESO
            /* Añadir una condición if para combrobar que el valor ingresado
            sea válido.
            */
            if (n > 0 || n < 999999)
            {
                /*Añadir un ciclo for que cumpla con las siguientes condiciones
                1. Definir una nueva variable d (divisores) como 1, para que comience a dividir desde este valor.
                2. Que de sea <=n para que se tenga hasta el valor ingresado
                3. d++ para que vaya incrementando su valor hasta n.
                */
                for (int d = 1; d <= n; d++)
                {
                
                /* 
                Añadir dentro del ciclo una condición donde:
                El % (módulo) representa a los residuos que tiene una división. 
                == 0, para que tome en cuenta los residuos iguales a 0
                */
                if (n % d == 0) 
                {
                    ContarValor++; // Contará los valores cuyos residuos son iguales a 0.
                }
               
                }

                // SALIDA
                // Añadir una condición fuera del ciclo
                /* Establece que si los valores que fueron contados 
                son mayores a dos residuos, entonces no son números primos*/

                if (ContarValor > 2)
                {
                    Console.WriteLine(n + " no es un número primo");
                }
                else // De lo contario, si será un númeor primo
                {
                    Console.WriteLine(n + " es un número primo");
                }

            }
            
            Console.ReadKey();
            }
        }
    }

